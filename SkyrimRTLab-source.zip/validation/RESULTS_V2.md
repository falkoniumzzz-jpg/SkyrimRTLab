# Validierung am 27.10.2026

- Microsoft DXC, cs_6_6: GI plain/raw/reblur/relax, jeweils MAX_SAMPLES=1 und 2,
  MAX_BOUNCES=2, USE_RAY_QUERY=1: alle acht erfolgreich.
- Rohprotokolle `validation/v2-logs/gi-*.log`; vorhandene SKYRIM-Makro-Neudefinitionswarnung.
- Exakter ursprünglicher RAW/non-NRD-Shader: Compilerfehler wegen diffHitDist/specHitDist
  reproduziert. Reparierte Variante kompiliert. `baseline-raw.log` ist der erwartete Negativtest.
- Reparaturskript angewendet und erneut angewendet; idempotent. Python-Syntaxprüfung und
  git diff --check bestanden.
- NRD-C++-Änderungen gegen die tatsächlichen CommonSettings-Felder und AccumulationMode
  der gepinnten NRD-Header geprüft, aber nicht als vollständige Plugin-DLL kompiliert.
- Tests für SHaRC-, SER-, SBT-, Subsurface-, ReSTIR- und weitere Shaderkombinationen offen.
- Keine GPU-/Skyrim-Ausführung, kein MSVC-Gesamtbuild, keine gemessenen FPS/Frametimes/VRAM-
  Verbesserungen. Die v1-Probe-Compilerprotokolle sind historische, keine neuen Laufzeittests.

Linux-Staging vereinheitlicht ausschließlich Dateinamen und Include-Pfadschreibweisen,
um das Windows-Dateisystemverhalten nachzubilden. Shadercode und Defines stehen im Prüfskript.
