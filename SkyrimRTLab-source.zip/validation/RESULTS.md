# Ausgeführte Prüfungen — 23.10.2026

Diese Datei beschreibt lokale Prüfungen in einer Linux-Umgebung. Kein Zugriff auf
Windows, Skyrim, die RTX 5080 oder einen GitHub-Actions-Run des Nutzers.

| Prüfung | Ergebnis |
|---|---|
| CMake-Konfiguration der Windows-Probe mit MinGW x64 | Erfolgreich |
| Probe C++20 kompilieren und zu Windows PE32+ x86-64 linken | Erfolgreich |
| Probe.hlsl, cs_6_5, Microsoft DXC | Erfolgreich |
| ShadowLab.hlsl, cs_6_5, RTLAB_INLINE=1, DXC | Erfolgreich |
| ShadowLab.hlsl, lib_6_5, RTLAB_INLINE=0, DXC | Erfolgreich |
| Vergleich von 27 Settings-/Enum-Deklarationen | Erfolgreich |
| Vier Tests gegen Feld-/Enum-ABI-Drift | Erfolgreich |
| Erneutes Anwenden der Quellcodeänderungen | Erfolgreich, idempotent |
| DX11-Composite mit Windows FXC | Nicht lokal ausgeführt; im Windows-Workflow vorgesehen |
| Vollständige CommunityShaders.dll/CER.dll mit MSVC | Nicht ausgeführt |
| Probe auf tatsächlicher DXR-GPU | Nicht ausgeführt |
| Skyrim-Integration/Absturzfreiheit/Performance | Nicht getestet |

Toolchain: CMake 4.2.3; MinGW GCC 13; DirectX-Headers Commit
`d873b344dc540898868697245f100c2a67fe68d9`; Microsoft DXC-Release `v1.8.2505.1`,
Linux-Archiv `linux_dxc_2025_07_14.x86_64.tar.gz`.
DXC meldet in diesem offiziellen Archiv intern `1.9(dev;4950-b106a961)`.

Das ursprüngliche Probe-Linkproblem durch MinGW-UUID-Spezialisierungen wurde durch
explizite offizielle IID-Konstanten und GUID-Definitionen behoben. Der finale CMake-Build
hat Exitcode 0. Eine anfängliche fehlende Ninja-PATH-Konfiguration wurde behoben.
Ein erfolgloser Versuch der globalen MinGW-Installation wurde durch lokale Entpackung
der Pakete ersetzt. Diese Toolchain ist kein Bestandteil des Lieferpakets.

Die Rohprotokolle unter `validation/logs` sowie die erzeugten DXIL-Dateien dokumentieren
die Compilerprüfungen. Die kompilierte EXE selbst wird im Source-Paket nicht mitverteilt.
Der Windows-Workflow baut sie neu. Ein grüner Workflow wäre ein Build-Erfolg, kein
Nachweis für GPU-Ausführung oder ein funktionierendes Skyrim-Raytracing.
