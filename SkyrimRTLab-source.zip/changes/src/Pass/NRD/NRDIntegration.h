#pragma once

#include <PCH.h>

#include "Pass/RenderPass.h"

#include <NRD.h>

namespace Pass::NRD
{
	class NRDIntegration : public RenderPass
	{
		struct Pipeline
		{
			nvrhi::ShaderHandle shader;
			nvrhi::ComputePipelineHandle pipeline;
			eastl::string debugName;
		};

		struct DispatchBindingCache
		{
			eastl::vector<nvrhi::ITexture*> textures;
			nvrhi::BindingSetHandle bindingSet;
		};

		Mode m_Mode;

		nrd::Denoiser kDenoiser;
		nrd::Identifier kDenoiserIdentifier;

		nvrhi::SamplerHandle m_NearestClampSampler;
		nvrhi::SamplerHandle m_LinearClampSampler;

		nvrhi::BindingLayoutHandle m_GlobalBindingLayout;
		nvrhi::BindingLayoutHandle m_ResourceBindingLayout;
		nvrhi::BindingSetHandle m_GlobalBindingSet;
		nvrhi::BufferHandle m_ConstantBuffer;

		eastl::vector<Pipeline> m_Pipelines;
		eastl::vector<nvrhi::TextureHandle> m_PermanentPool;
		eastl::vector<nvrhi::TextureHandle> m_TransientPool;

		nvrhi::TextureHandle m_MotionVectorsScratch;
		nvrhi::TextureHandle m_FallbackSrvTexture;
		nvrhi::TextureHandle m_FallbackUavTexture;

		nrd::Instance* m_NRD = nullptr;
		nrd::ReblurSettings m_ReblurSettings = {};
		nrd::RelaxSettings m_RelaxSettings = {};

		nrd::CommonSettings m_CommonSettings = {};

		bool IsRelax() const { return kDenoiser == nrd::Denoiser::RELAX_DIFFUSE_SPECULAR; }

		eastl::vector<DispatchBindingCache> m_DispatchBindingCaches;

		bool m_ResourcesDirty = true;
        bool m_ResetHistory = true;
        uint32_t m_LastHistoryFrame = 0;
		bool m_SettingsDirty = true;

		void Setup();
		void DestroyInstance();
		void CreateBindingLayouts();
		void CreatePipelines();
		void CreateResources();
		void CreateGlobalBindingSet();

		void UpdateCommonSettings();
		void UpdateSettings(const Settings& settings);

		nvrhi::ITexture* GetDispatchResource(const nrd::ResourceDesc& resource) const;
		nvrhi::Format GetFormat(nrd::Format format) const;

		bool IsDownscaled() const;

		uint32_t GetMaxResourceCount(nrd::DescriptorType type) const;

	public:
		NRDIntegration(Renderer* renderer, nrd::Denoiser denoiser, Mode mode);
		~NRDIntegration() override;

		virtual void Initialize() override;

		void SettingsChanged(const Settings& settings) override;
		void ResolutionChanged(uint2 resolution) override;
		void Execute(nvrhi::ICommandList* commandList) override;
	};
}
